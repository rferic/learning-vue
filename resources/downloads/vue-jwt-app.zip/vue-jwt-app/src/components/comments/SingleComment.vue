<template>
  <div class="col-sm-8 col-sm-offset-2 single-comment">
    <div class="panel panel-default arrow right">
      <div class="panel-heading">Respuesta</div>
      <div class="panel-body">

        <header class="text-left">

          <div class="comment-user">
            <i class="fa fa-user"></i> {{ comment.postedBy.username }}
          </div>

          <time class="comment-date">
            <i class="fa fa-clock-o"></i>
            {{ comment.date | formatDate }}
          </time>

        </header>

        <hr />

        <div class="comment-post">
          <p>
            {{ comment.body }}
          </p>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'single-comment',
    props: ['comment']
  }
</script>

<style scoped>
  /* http://bootsnipp.com/snippets/featured/comment-posts-layout */
  /*font Awesome http://fontawesome.io*/
  @import url(//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css);
  /*Comment List styles*/
  .comment-list .row {
    margin-bottom: 0px;
  }
  .comment-list .panel .panel-heading {
    padding: 4px 15px;
    position: absolute;
    border:none;
    /*Panel-heading border radius*/
    border-top-right-radius:0px;
    top: 1px;
  }
  .comment-list .panel .panel-heading.right {
    border-right-width: 0px;
    /*Panel-heading border radius*/
    border-top-left-radius:0px;
    right: 16px;
  }
  .comment-list .panel .panel-heading .panel-body {
    padding-top: 6px;
  }
  .comment-list figcaption {
    /*For wrapping text in thumbnail*/
    word-wrap: break-word;
  }
  /* Portrait tablets and medium desktops */
  @media (min-width: 768px) {
    .comment-list .arrow:after, .comment-list .arrow:before {
      content: "";
      position: absolute;
      width: 0;
      height: 0;
      border-style: solid;
      border-color: transparent;
    }
    .comment-list .panel.arrow.left:after, .comment-list .panel.arrow.left:before {
      border-left: 0;
    }
    /*****Left Arrow*****/
    /*Outline effect style*/
    .comment-list .panel.arrow.left:before {
      left: 0px;
      top: 30px;
      /*Use boarder color of panel*/
      border-right-color: inherit;
      border-width: 16px;
    }
    /*Background color effect*/
    .comment-list .panel.arrow.left:after {
      left: 1px;
      top: 31px;
      /*Change for different outline color*/
      border-right-color: #FFFFFF;
      border-width: 15px;
    }
    /*****Right Arrow*****/
    /*Outline effect style*/
    .comment-list .panel.arrow.right:before {
      right: -16px;
      top: 30px;
      /*Use boarder color of panel*/
      border-left-color: inherit;
      border-width: 16px;
    }
    /*Background color effect*/
    .comment-list .panel.arrow.right:after {
      right: -14px;
      top: 31px;
      /*Change for different outline color*/
      border-left-color: #FFFFFF;
      border-width: 15px;
    }
  }
  .comment-list .comment-post {
    margin-top: 6px;
  }
</style>
