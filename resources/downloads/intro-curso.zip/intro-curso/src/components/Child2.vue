<template>
  <div class="child2">
    <h1>Child 2</h1>
  </div>
</template>

<script>
  export default {

  }
</script>
